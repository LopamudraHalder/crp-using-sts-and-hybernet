package com.register;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MainController {
	@RequestMapping("/")
	public String homePage(HttpSession session){
		String user = (String) session.getAttribute("user");
		if(user!=null){
			if(user.equalsIgnoreCase("faculty")){
				return "redirect:/home_faculty";
			}
			if(user.equalsIgnoreCase("student")){
				return "redirect:/home_student";
			}
		} 
		return "redirect:/login";
	}
	@RequestMapping("home_student")
	public String home_student(){
		return "home_student";
	}
	@RequestMapping("home_faculty")
	public String home_faculty(){
		return "home_faculty";
	}
	@RequestMapping("/login")
	public String loginPage(){
		return "login";
	}
	@RequestMapping("/logout")
	public String logout(HttpSession session){
		session.invalidate();
		return "redirect:/";
	}
}
