package com.register.Library;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.register.Student.Student;

import lombok.Data;

@Data
@Entity
public class BookRecord {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long Id;

	@ManyToOne
	@JoinColumn(referencedColumnName = "student_id")
	private Student student;

	@ManyToOne
	@JoinColumn(referencedColumnName = "book_id")
	private Book book;

	private Date dueDate;
}
