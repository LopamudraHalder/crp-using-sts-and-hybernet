package com.register.Library;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookRecordService {

	@Autowired
	private BookRecordRepository repository;

	public List<BookRecord> listAll() {

		return repository.findAll();
	}

	public void create(BookRecord BookRecord) {

		repository.save(BookRecord);
	}

	public BookRecord updateid(Long id) {
		return repository.findById(id).get();
	}

	public void delete(Long id) {

		repository.deleteById(id);
	}
	
}

