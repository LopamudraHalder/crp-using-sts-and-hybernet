package com.register.Library;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/library")
public class LibraryController {
	@RequestMapping("")
	public String viewIndexPage(Model model) {
		return "library/index";
	}

	/*
	 * @RequestMapping("faculty") public String viewIndexPage_faculty(Model model) {
	 * return "library/faculty"; }
	 */
	@RequestMapping("student")
	public String viewIndexPage_student(Model model) {
		return "library/student";
	}

}
