package com.register.Library;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/library/bookrecord_student")
public class BookRecordControllerStudent {

	@Autowired
	BookService bookservice;

	@Autowired
	BookRecordService bookrecordservice;

	@RequestMapping("")
	public String viewIndexPage(Model model) {
		List<BookRecord> BookRecordList = bookrecordservice.listAll();
		model.addAttribute("bookrecordList", BookRecordList);
		return "library/bookrecord_student";
	}

	/*
	 * 
	 * @RequestMapping("/new_add") public String viewNewBookRecordForm(Model model)
	 * { BookRecord BookRecord = new BookRecord(); model.addAttribute("bookrecord",
	 * BookRecord); return "library/bookrecord"; }
	 * 
	 * @RequestMapping(value = "/save_bookrecord", method = RequestMethod.POST)
	 * public String addNewBookRecord(@ModelAttribute("BookRecord") BookRecord
	 * BookRecord) { bookrecordservice.create(BookRecord); return
	 * "redirect:/library/bookrecord"; }
	 * 
	 * @RequestMapping("/edit/{id}") public ModelAndView
	 * viewEditBookRecordForm(@PathVariable(name = "id") long id) { ModelAndView mav
	 * = new ModelAndView("library/bookrecord/update"); BookRecord BookRecord =
	 * bookrecordservice.updateid(id); mav.addObject("bookrecord", BookRecord);
	 * return mav; }
	 * 
	 * @RequestMapping("/delete/{id}") public String
	 * deleteBookRecord(@PathVariable(name = "id") long id) {
	 * bookrecordservice.delete(id); return "redirect:/library/bookrecord"; }
	 */
}
