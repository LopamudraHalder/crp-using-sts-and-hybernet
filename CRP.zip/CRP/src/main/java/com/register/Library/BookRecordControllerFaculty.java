package com.register.Library;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/library/bookrecord")
public class BookRecordControllerFaculty {
	
	@Autowired
	BookService bookservice;
	
	@Autowired
	BookRecordService bookrecordservice;
	
	@RequestMapping("")
	public String viewIndexPage(Model model) {
		List<BookRecord> BookRecordList = bookrecordservice.listAll();
		model.addAttribute("bookrecordList", BookRecordList);
		return "library/bookrecord/index";
	}

	@RequestMapping("/new_add")
	public String viewNewBookRecordForm(Model model) {
		BookRecord BookRecord = new BookRecord();
		model.addAttribute("bookrecord", BookRecord);
		return "library/bookrecord";
	}

	@RequestMapping(value = "/save_bookrecord", method = RequestMethod.POST)
	public String addNewBookRecord(@ModelAttribute("BookRecord") BookRecord BookRecord) {
		bookrecordservice.create(BookRecord);
		return "redirect:/library/bookrecord";
	}

	@RequestMapping("/edit/{id}")
	public ModelAndView viewEditBookRecordForm(@PathVariable(name = "id") long id) {
		ModelAndView mav = new ModelAndView("library/bookrecord/update");
		BookRecord BookRecord = bookrecordservice.updateid(id);
		mav.addObject("bookrecord", BookRecord);
		return mav;
	}

	@RequestMapping("/delete/{id}")
	public String deleteBookRecord(@PathVariable(name = "id") long id) {
		bookrecordservice.delete(id);
		return "redirect:/library/bookrecord";
	}
}
