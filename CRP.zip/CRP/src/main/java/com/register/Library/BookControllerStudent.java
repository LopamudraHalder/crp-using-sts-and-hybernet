package com.register.Library;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/library/book_student")
public class BookControllerStudent {

	@Autowired
	BookService bookservice;

	@Autowired
	BookRecordService bookrecordservice;

	@RequestMapping("")
	public String viewIndexPage(Model model) {
		List<Book> bookList = bookservice.listAll();
		model.addAttribute("bookList", bookList);
		return "library/book_student";
	}

	/*
	 * @RequestMapping("/new_add") public String viewNewBookForm(Model model) { Book
	 * book = new Book(); model.addAttribute("book", book); return "library/book"; }
	 * 
	 * @RequestMapping(value = "/save_book", method = RequestMethod.POST) public
	 * String addNewBook(@ModelAttribute("book") Book book) {
	 * bookservice.create(book); return "redirect:/library/book"; }
	 * 
	 * @RequestMapping("/edit/{id}") public ModelAndView
	 * viewEditBookForm(@PathVariable(name = "id") long id) { ModelAndView mav = new
	 * ModelAndView("library/book/update"); Book book= bookservice.updateid(id);
	 * mav.addObject("book", book); return mav; }
	 * 
	 * @RequestMapping("/delete/{id}") public String deleteBook(@PathVariable(name =
	 * "id") long id) { bookservice.delete(id); return "redirect:/library/book"; }
	 */
}
