package com.register.searchengine;

//import java.util.Arrays;
//import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;

public class search {

	@Autowired
	HttpSession session;

	// public List<Object> doSearch(Object service,Object criteria){
	// return Arrays.asList(service.find(criteria.getClass().getName())
	// .apply(criteria));
	// }
}
