package com.register.Faculty;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FacultyService {

	@Autowired
	private FacultyRepository repository;

	public List<Faculty> listAll() {

		return repository.findAll();
	}

	public void create(Faculty faculty) {

		repository.save(faculty);
	}

	public Faculty updateid(Long id) {
		return repository.findById(id).get();
	}

	public void delete(Long id) {

		repository.deleteById(id);
	}
	
}
