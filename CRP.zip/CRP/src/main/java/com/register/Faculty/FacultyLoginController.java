package com.register.Faculty;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class FacultyLoginController {
    @Autowired
    FacultyService service;

    @RequestMapping(value = "/faculty/login_faculty", method = RequestMethod.POST)
	public String welcomePage(@ModelAttribute("faculty") Faculty faculty,HttpSession session) {
		try{
			Faculty f = service.updateid(faculty.getId());
			if(f!=null) {
				if(f.getPassword().equals(faculty.getPassword())) {
					session.setAttribute("user", "faculty");
					return "redirect:/home_faculty";
				}
			}
		} catch (Exception e) {
			return "redirect:/";
		}
		return "redirect:/";
	}
}
