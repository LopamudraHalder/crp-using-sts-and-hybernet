package com.register.Faculty;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "tbl_faculty")
@Data
public class Faculty {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "faculty_id")
	private Long id;

	@Column(name = "faculty_firstname")
	private String firstname;

	@Column(name = "faculty_lastname")
	private String lastname;

	@Column(name = "faculty_email")
	private String email;

	private String password;

	@Column(name = "faculty_gender")
	private String gender;

	private String subject;

}
