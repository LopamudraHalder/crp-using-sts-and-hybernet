package com.register.Faculty;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/faculty")
public class FacultyController {

	@Autowired
	private FacultyService service;

	@RequestMapping("")
	public String viewIndexPage(Model model) {
		List<Faculty> facultyList = service.listAll();
		model.addAttribute("facultyList", facultyList);
		return "faculty/index";
	}

	@RequestMapping("/new_add")
	public String viewNewFacultyForm(Model model) {
		Faculty faculty = new Faculty();
		model.addAttribute("faculty", faculty);
		return "faculty";
	}

	@RequestMapping(value = "/save_faculty", method = RequestMethod.POST)
	public String addNewFaculty(@ModelAttribute("faculty") Faculty faculty) {
		service.create(faculty);
		return "redirect:/faculty";
	}

	@RequestMapping("/edit/{id}")
	public ModelAndView viewEditFacultyForm(@PathVariable(name = "id") long id) {
		ModelAndView mav = new ModelAndView("faculty/update");
		Faculty faculty = service.updateid(id);
		mav.addObject("faculty", faculty);
		return mav;
	}

	@RequestMapping("/delete/{id}")
	public String deletefaculty(@PathVariable(name = "id") long id) {
		service.delete(id);
		return "redirect:/faculty";
	}

}
