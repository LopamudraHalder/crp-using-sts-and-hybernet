package com.register.Attendance;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AttendanceService {

	@Autowired
	private AttendanceRepository attendanceRepository;

	public List<Attendance> listAll() {

		return attendanceRepository.findAll();
	}

	public void create(Attendance attendance) {
		attendanceRepository.save(attendance);
	}

	public Attendance updateid(Long id) {
		return attendanceRepository.findById(id).get();
	}

	public void delete(Long id) {
		attendanceRepository.deleteById(id);
	}
}