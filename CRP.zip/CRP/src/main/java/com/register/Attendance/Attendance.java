package com.register.Attendance;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.register.Student.Student;

import lombok.Data;

@Entity
@Table(name = "attendance_detail")
@Data
public class Attendance {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long Id;

	@ManyToOne
	@JoinColumn(referencedColumnName = "student_id")
	private Student student;

	@Column(name = "student_attendanceStatus")
	private Boolean attendance_status;

	@Column(name = "attendance_date")
	private Date date;

}