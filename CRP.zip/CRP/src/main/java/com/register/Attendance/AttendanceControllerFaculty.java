package com.register.Attendance;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/attendance")
public class AttendanceControllerFaculty {

	@Autowired
	private AttendanceService service;

	@RequestMapping("")
	public String viewIndexPage(Model model) {
		List<Attendance> attendanceList = service.listAll();
		model.addAttribute("attendanceList", attendanceList);
		return "attendance/index";
	}

	@RequestMapping("/new_add")
	public String viewNewStudentForm(Model model) {
		Attendance attendance = new Attendance();
		model.addAttribute("attendance", attendance);
		return "attendance";
	}

	@RequestMapping(value = "/save_attendance", method = RequestMethod.POST)
	public String addNewAttendance(@ModelAttribute("attendance") Attendance attendance) {
		service.create(attendance);
		return "redirect:/attendance";
	}

	@RequestMapping("/edit/{id}")
	public ModelAndView viewEditAttendanceForm(@PathVariable(name = "id") long id) {

		ModelAndView mav = new ModelAndView("attendance/update");
		Attendance attendance = service.updateid(id);
		mav.addObject("attendance", attendance);
		return mav;
	}

	@RequestMapping("/delete/{id}")
	public String deleteStudent(@PathVariable(name = "id") long id) {

		service.delete(id);
		return "redirect:/attendance";
	}
}
