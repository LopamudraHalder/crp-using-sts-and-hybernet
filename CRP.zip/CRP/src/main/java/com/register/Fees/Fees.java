package com.register.Fees;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "tbl_fees")
@Data
public class Fees {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "payment_id")
	private long id;

	@Column(name = "student_id")
	private int student_id;

	@Column(name = "due_date")
	private Date duedate;

	@Column(name = "paid_status")
	private boolean paid;

	@Column(name = "payment_date")
	private Date payment_date;
}
