package com.register.Fees;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/fees/student")
public class FeesControllerStudent {

	@Autowired
	private FeesService service;

	@RequestMapping("")
	public String viewIndexPage(Model model) {
		List<Fees> feesList = service.listAll();
		model.addAttribute("feesList", feesList);
		return "fees/index";
	}

	@RequestMapping("/show")
	public String showTable(Model model) {
		List<Fees> feesList = service.listAll();
		model.addAttribute("feesList", feesList);
		return "fees/fees_student";
	}

	/*
	 * @RequestMapping("/new_add") public String viewNewStudentForm(Model model) {
	 * Fees Fees = new Fees(); model.addAttribute("fees", Fees); return
	 * "fees/student"; }
	 * 
	 * @RequestMapping(value = "/save_fees", method = RequestMethod.POST) public
	 * String addNewStudent(@ModelAttribute("fees") Fees Fees) {
	 * service.create(Fees); return "redirect:/fees/student"; }
	 * 
	 * 
	 * @RequestMapping("/edit/{id}") public ModelAndView
	 * viewEditStudentForm(@PathVariable(name = "id") long id) { ModelAndView mav =
	 * new ModelAndView("fees/update"); Fees Fees = service.updateid(id);
	 * mav.addObject("fees", Fees); return mav; }
	 * 
	 * @RequestMapping("/delete/{id}") public String
	 * deleteStudent(@PathVariable(name = "id") long id) { service.delete(id);
	 * return "redirect:/fees"; }
	 */

}
