package com.register.Fees;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FeesService {
	
	@Autowired
	private FeesRepository repository;
	
	public List<Fees> listAll()
	{
		return repository.findAll();
	}
	
	public void create(Fees Fees)
	{
		repository.save(Fees);
	}
	
	public Fees updateid(Long id)
	{
		return repository.findById(id).get();
	}
	
	public void delete(Long id)
	{
		repository.deleteById(id);
	}

}
