package com.register.Student;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class StudentLoginController {
    @Autowired
    StudentService service;

    @RequestMapping(value = "/student/login_student", method = RequestMethod.POST)
	public String welcomePage(@ModelAttribute("student") Student student,HttpSession session) {
		try {
			Student s = service.updateid(student.getId());
			if(s!=null) {
				if(s.getPassword().equals(student.getPassword())) {
					session.setAttribute("user", "student");
					return "redirect:/home_student";
				}
			}
		} catch (Exception e) {
			return "redirect:/";
		}
		return "redirect:/";
	}
}
