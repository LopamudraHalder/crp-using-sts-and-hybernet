package com.register.Student;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "tbl_student")
@Data
public class Student {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "student_id")
	private Long id;

	@Column(name = "student_firstname")
	private String firstname;

	@Column(name = "student_lastname")
	private String lastname;

	@Column(name = "student_email")
	private String email;

	private String password;

	@Column(name = "student_gender")
	private String gender;

	private String course;
}
